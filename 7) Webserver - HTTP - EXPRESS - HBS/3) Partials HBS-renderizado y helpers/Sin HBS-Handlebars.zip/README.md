# Temas de la esta carpeta: 

Aquí cubriremos varios temas como: 

- Se creo un carpeta "public" donde esta va contener los documentos html que queremos que sean publico

- Se instalo Express para poder crear un servidor y mostrar la info del mismo